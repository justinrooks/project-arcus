import Foundation
public struct HTTPResponse: Sendable {
    public enum Source: Sendable, Equatable, CustomStringConvertible {
        case live
        case localCache
        case cacheFallback
        case cacheRevalidated304

        public var description: String {
            switch self {
            case .live:
                "live"
            case .localCache:
                "localCache"
            case .cacheFallback:
                "cacheFallback"
            case .cacheRevalidated304:
                "cacheRevalidated304"
            }
        }

        var isNetworkBacked: Bool {
            switch self {
            case .live, .cacheRevalidated304:
                true
            case .localCache, .cacheFallback:
                false
            }
        }
    }

    public let status: Int
    public let headers: [String: String]
    public let data: Data?
    public let source: Source

    public init(
        status: Int,
        headers: [String: String],
        data: Data?,
        source: Source = .live
    ) {
        self.status = status
        self.headers = headers
        self.data = data
        self.source = source
    }

    public func header(_ name: String) -> String? {
        headers.first { $0.key.caseInsensitiveCompare(name) == .orderedSame }?.value
    }

}
